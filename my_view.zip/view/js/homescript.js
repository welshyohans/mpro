function alertMe(){
    alert("yes you did it!");
}

function butttonClick(){
    alert("yes you click it!");	
}
function updateGoods(){
    alert("you can update me");
}